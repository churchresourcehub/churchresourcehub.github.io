app.scriptPreferences.userInteractionLevel = UserInteractionLevels.NEVER_INTERACT;
var out = [];
try {
  var doc = app.open(File("/Users/woodslisenby/Library/CloudStorage/OneDrive-SpanishFortUnitedMethodistChurch/Communications Assistant's files - Summerlyn and Jennifer's Files/Bulletins & Inserts/2026 Bulletins & Inserts/Bulletin - 2026-09-06 - The Way - Walking with Others - Combined (InDesign)/Bulletin - 2026-09-06 - The Way - Walking with Others - Combined.idml"));
  doc.exportFile(ExportFormat.PDF_TYPE, File("/Users/woodslisenby/Library/CloudStorage/OneDrive-SpanishFortUnitedMethodistChurch/Communications Assistant's files - Summerlyn and Jennifer's Files/Bulletins & Inserts/2026 Bulletins & Inserts/Bulletin - 2026-09-06 - The Way - Walking with Others - Combined (InDesign)/Bulletin - 2026-09-06 - The Way - Walking with Others - Combined - proof.pdf"), false, app.pdfExportPresets.itemByName("[High Quality Print]"));
  doc.save(File("/Users/woodslisenby/Library/CloudStorage/OneDrive-SpanishFortUnitedMethodistChurch/Communications Assistant's files - Summerlyn and Jennifer's Files/Bulletins & Inserts/2026 Bulletins & Inserts/Bulletin - 2026-09-06 - The Way - Walking with Others - Combined (InDesign)/Bulletin - 2026-09-06 - The Way - Walking with Others - Combined.indd"));
  out.push("PAGES " + doc.pages.length);
  for (var i = 0; i < doc.fonts.length; i++) out.push("  " + doc.fonts[i].name + " => " + doc.fonts[i].status.toString());
  for (var i = 0; i < doc.links.length; i++) if (doc.links[i].status != LinkStatus.NORMAL) out.push("  LINK " + doc.links[i].name + " => " + doc.links[i].status.toString());
  var tfs = doc.textFrames; for (var i = 0; i < tfs.length; i++) if (tfs[i].overflows) out.push("  OVERSET " + tfs[i].name);
  doc.close(SaveOptions.NO);
} catch (e) { out.push("ERROR: " + e.message + " line " + e.line); }
out.join("\n");
