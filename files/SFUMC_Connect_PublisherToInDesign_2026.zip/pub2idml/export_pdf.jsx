app.scriptPreferences.userInteractionLevel = UserInteractionLevels.NEVER_INTERACT;
var out = [];
try {
  var doc = app.open(File("/private/tmp/claude-501/-Users-woodslisenby/3d6f371c-0830-4ad3-a823-77f838aec6b9/scratchpad/build/Bulletin - 2026-09-13 - Wells We Didn't Dig.idml"));
  var pdfFile = File("/private/tmp/claude-501/-Users-woodslisenby/3d6f371c-0830-4ad3-a823-77f838aec6b9/scratchpad/build/proof.pdf");
  doc.exportFile(ExportFormat.PDF_TYPE, pdfFile, false, app.pdfExportPresets.itemByName("[High Quality Print]"));
  doc.save(File("/private/tmp/claude-501/-Users-woodslisenby/3d6f371c-0830-4ad3-a823-77f838aec6b9/scratchpad/build/Bulletin - 2026-09-13 - Wells We Didn't Dig.indd"));
  out.push("PAGES " + doc.pages.length + " size " + doc.documentPreferences.pageWidth + " x " + doc.documentPreferences.pageHeight);
  out.push("FONTS:");
  for (var i = 0; i < doc.fonts.length; i++) out.push("  " + doc.fonts[i].name + " => " + doc.fonts[i].status.toString());
  out.push("LINKS:");
  for (var i = 0; i < doc.links.length; i++) out.push("  " + doc.links[i].name + " => " + doc.links[i].status.toString());
  out.push("OVERSET:");
  var tfs = doc.textFrames;
  for (var i = 0; i < tfs.length; i++) if (tfs[i].overflows) out.push("  " + tfs[i].name + " overflows");
  doc.close(SaveOptions.NO);
} catch (e) { out.push("ERROR: " + e.message + " line " + e.line); }
out.join("\n");
