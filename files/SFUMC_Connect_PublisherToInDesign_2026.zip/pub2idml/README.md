# pub2idml — Publisher bulletin → InDesign conversion notes (Sept 2026)

One-off pipeline used to convert `Bulletin - 2026-09-13 - Wells We Didn't Dig.pub` to an InDesign IDML package.

How the .pub was decoded (no Publisher needed):
- `olefile` opens the .pub (OLE compound file).
- `Quill/QuillSub/CONTENTS`: text. Chunk list at 0x18; `STRS` = story lengths, `SYID` = story ids, `TEXT` = UTF-16LE text. → `stories.json` (keyed by text id).
- `Contents`: trailer offset at 0x1A; block directory gives chunk refs (type 0x43 page, 0x01 shape, 0x30 group). Page chunks list shape seq numbers; shape chunks carry text id (block id 0x27). NOTE: chunk seq numbering in my parser was off by one vs. Escher seq (chunk = escher + 1).
- `Escher/EscherStm`: DggContainer + BStore, then per-page DgContainers each preceded by a 4-byte value (libmspub chokes on this, which is why pub2raw/LibreOffice fail). Shape coords are in ClientAnchor as (u16 id, u32 EMU) pairs, ids 0x2001..0x2004, relative to the PAGE CENTER. Picture index = OPT prop 0x0104 (pib); crops = 0x0100..0x0103 (16.16 fractions). One empty BSE slot (#183) shifts later pib→blip by one.
- `Escher/EscherDelayStm`: blips in BSE order.
- Page 1224x792 pt (17x11); PDF coords = pub coords + (612, 396).

`make_idml.py` writes the IDML (styles, spreads, stories, links). `export_pdf.jsx` opens it in InDesign 2026 via `osascript ... do script ... language javascript`, exports a PDF and saves .indd.

## Sept 28, 2026 — combined-service template
- `extract_pub.py file.pub outdir` now does the whole decode (stories.json, pages.json with PDF-space boxes/crops/pictures, blips/).
- `make_idml_combined.py OUTDIR` (env `STORIES=path/to/stories.json`) builds the combined layout: red New Spirit title, one order-of-worship story threaded across two frames, creed-aware parser, original navy/labyrinth cover. `export_combined.jsx` drives InDesign.
- Link URIs must be percent-encoded and XML-escaped (OneDrive path has `&` and `'`).
- Output: OneDrive → Bulletins & Inserts → 2026 → "Bulletin - 2026-09-06 - … - Combined (InDesign)/".
