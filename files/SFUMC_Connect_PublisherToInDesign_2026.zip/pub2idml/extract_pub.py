#!/usr/bin/env python3
"""Decode a Microsoft Publisher (.pub, Publisher 2003+/365 format) file without Publisher.

Usage: extract_pub.py file.pub outdir

Writes to outdir:
  stories.json   text stories keyed by text id (UTF-16 text, paragraphs separated by \\r)
  pages.json     for each page in order: shapes with PDF-style page coordinates (points, origin top-left
                 of a 17x11 page), picture file, crop fractions, fill/line, text id, group membership
  blips/         every embedded picture, named blipNNN.ext by blip-store index (1-based, as referenced by pib)

Coordinate note: Publisher stores shape boxes relative to the page centre. PDF coords below assume the
document page is the printed page (docsize from the Contents stream is usually 0.25in larger on each side).
"""
import sys, os, json, struct
import olefile

src, out = sys.argv[1], sys.argv[2]
os.makedirs(os.path.join(out, "blips"), exist_ok=True)
ole = olefile.OleFileIO(src)
EMU = 12700.0

# ------------------------------------------------------------ Quill text
q = ole.openstream("Quill/QuillSub/CONTENTS").read()
refs = []; lo = 0x18
while lo != 0xFFFFFFFF:
    n = struct.unpack_from("<H", q, lo + 2)[0]; nxt = struct.unpack_from("<I", q, lo + 4)[0]
    p = lo + 8
    for i in range(n):
        name = q[p + 2:p + 6].decode("latin1"); off, ln = struct.unpack_from("<II", q, p + 16)
        refs.append((name, off, ln)); p += 24
    lo = nxt
strs = [r for r in refs if r[0] == "STRS"][0]; syid = [r for r in refs if r[0] == "SYID"][0]; text = [r for r in refs if r[0] == "TEXT"][0]
p = strs[1]; num = struct.unpack_from("<I", q, p)[0]; skip = struct.unpack_from("<I", q, p + 4)[0]; p = strs[1] + 4 + skip
lengths = [struct.unpack_from("<I", q, p + 4 * j)[0] for j in range(num)]
p = syid[1] + 4; nid = struct.unpack_from("<I", q, p)[0]; ids = [struct.unpack_from("<I", q, p + 4 + 4 * j)[0] for j in range(nid)]
off = text[1]; stories = {}
for L, tid in zip(lengths, ids):
    stories[str(tid)] = q[off:off + 2 * L].decode("utf-16le", "replace"); off += 2 * L
json.dump(stories, open(os.path.join(out, "stories.json"), "w"), ensure_ascii=False, indent=0)

# ------------------------------------------------------------ Escher blips
d = ole.openstream("Escher/EscherDelayStm").read()
off = 0; idx = 0; blipfiles = {}
while off + 8 <= len(d):
    vi, typ, ln = struct.unpack_from("<HHI", d, off); inst = vi >> 4; body = off + 8; idx += 1
    if typ in (0xF01D, 0xF01E, 0xF02A, 0xF029, 0xF01F):
        two = {0xF01E: inst != 0x6E0, 0xF01D: inst not in (0x46A, 0x6E2), 0xF02A: inst not in (0x46B, 0x6E3), 0xF029: inst != 0x6E4, 0xF01F: inst != 0x7A8}[typ]
        start = body + 16 + (16 if two else 0) + 1
        ext = {0xF01D: "jpg", 0xF01E: "png", 0xF02A: "jpg", 0xF029: "tif", 0xF01F: "dib"}[typ]
        fn = f"blip{idx:03d}.{ext}"
        open(os.path.join(out, "blips", fn), "wb").write(d[start:body + ln]); blipfiles[idx] = fn
    off = body + ln

# BSE table: map pib -> delay-stream record index (empty BSE slots have no record)
e = ole.openstream("Escher/EscherStm").read()
i = e.find(b"\x01\xf0"); off = i - 2; vi, typ, ln = struct.unpack_from("<HHI", e, off)
p = off + 8; end = p + ln; k = 0; pib_to_rec = {}; rec = 0
while p + 8 <= end:
    vi, typ, l2 = struct.unpack_from("<HHI", e, p); body = p + 8; k += 1
    size = struct.unpack_from("<I", e, body + 20)[0]
    if size > 0:
        rec += 1; pib_to_rec[k] = rec
    p = body + l2

# ------------------------------------------------------------ Escher shapes
def s32(v): return v - (1 << 32) if v >= (1 << 31) else v
shapes = {}
def vals(body, ln):
    o = {}; p = body + 4
    while p + 6 <= body + ln:
        fid, v = struct.unpack_from("<HI", e, p); p += 6; o[fid] = v
    return o
def walk(off, end, depth, cur, grp):
    while off + 8 <= end:
        vi, typ, ln = struct.unpack_from("<HHI", e, off); ver = vi & 0xF; inst = vi >> 4
        if depth == 0 and typ not in (0xF002, 0xF003, 0xF004): off += 4; continue
        body = off + 8
        if ver == 0xF:
            if typ == 0xF004: cur = {"props": {}, "group": grp["cur"] if grp else None}
            if typ == 0xF003 and depth >= 2: grp = {"cur": None, "rect": None, "parent": grp}
            walk(body, body + ln, depth + 1, cur, grp)
            if typ == 0xF004 and cur and "seq" in cur:
                if cur.get("is_group_leader") and grp: grp["cur"] = cur["seq"]; grp["rect"] = cur.get("spgr")
                shapes[cur["seq"]] = cur
        else:
            if cur is not None:
                if typ == 0xF00A:
                    spid, flags = struct.unpack_from("<II", e, body); cur.update(spid=spid, flags=flags, st=inst, is_group_leader=bool(flags & 1))
                elif typ == 0xF009:
                    cur["spgr"] = [struct.unpack_from("<i", e, body + 4 * i)[0] / EMU for i in range(4)]
                elif typ in (0xF00B, 0xF121, 0xF122):
                    p = body
                    for i in range(inst):
                        pid, val = struct.unpack_from("<HI", e, p); p += 6; cur["props"][pid & 0x3FFF] = val
                elif typ == 0xF011:
                    v = vals(body, ln)
                    if 0x6801 in v: cur["seq"] = v[0x6801]
                elif typ == 0xF010:
                    a = vals(body, ln)
                    if 0x2001 in a: cur["box"] = [s32(a.get(kk, 0)) / EMU for kk in (0x2001, 0x2002, 0x2003, 0x2004)]
                elif typ == 0xF00F:
                    cur["child"] = [struct.unpack_from("<i", e, body + 4 * i)[0] / EMU for i in range(4)]
        off = body + ln
walk(8 + struct.unpack_from("<I", e, 4)[0], len(e), 0, None, None)

# ------------------------------------------------------------ Contents (pages, chunk text ids)
c = ole.openstream("Contents").read()
def blen(t):
    if t in (0x78, 0x5, 0x8, 0xa): return 0
    if t in (0x10, 0x12, 0x18, 0x1a, 0x07): return 2
    if t in (0x20, 0x22, 0x58, 0x68, 0x70, 0xb8): return 4
    if t == 0x28: return 8
    if t == 0x38: return 16
    if t == 0x48: return 24
    if t in (0xc0, 0x80, 0x82, 0x88, 0x8a, 0x90, 0x98, 0xa0): return -1
    return 0
def pb(p):
    bid = c[p]; bt = c[p + 1]; qq = p + 2; L = blen(bt)
    if L < 0:
        dl = struct.unpack_from("<I", c, qq)[0]; return dict(id=bid, type=bt, dataoff=qq, datalen=dl, data=None, end=qq + dl)
    val = {1: lambda: c[qq], 2: lambda: struct.unpack_from("<H", c, qq)[0], 4: lambda: struct.unpack_from("<I", c, qq)[0]}.get(L, lambda: None)()
    return dict(id=bid, type=bt, dataoff=qq, datalen=L, data=val, end=qq + L)
trailer = struct.unpack_from("<I", c, 0x1a)[0]; p = trailer + 4; chunks = []; seq = -1   # seq counted so that it matches Escher shape ids
for i in range(3):
    b = pb(p)
    if b["type"] == 0x90:
        qq = b["dataoff"] + 4
        while qq < b["dataoff"] + b["datalen"]:
            sb = pb(qq); seq += 1
            if sb["type"] == 0x88:
                r = sb["dataoff"] + 4; typ = off_ = par = None
                while r < sb["end"]:
                    x = pb(r)
                    if x["id"] == 2: typ = x["data"]
                    elif x["id"] == 4: off_ = x["data"]
                    elif x["id"] == 5: par = x["data"]
                    r = x["end"]
                chunks.append(dict(seq=seq, type=typ, off=off_, parent=par))
            qq = sb["end"]
    p = b["end"]
det = {}; pagelist = []; docsize = None
for ch in chunks:
    if ch["type"] in (1, 0x20, 0x30, 0x31, 0x10, 0x66):
        p = ch["off"]; L = struct.unpack_from("<I", c, p)[0]; qq = p + 4; dd = {"ctype": ch["type"], "parent": ch["parent"]}
        while qq < p + L:
            b = pb(qq)
            if b["id"] == 0x27 and b["data"] is not None: dd["text"] = b["data"]
            if b["id"] == 0xaa and b["data"] is not None: dd["w"] = round(b["data"] / EMU, 1)
            if b["id"] == 0xab and b["data"] is not None: dd["h"] = round(b["data"] / EMU, 1)
            qq = b["end"]
        det[ch["seq"]] = dd
    elif ch["type"] == 0x44:
        p = ch["off"]; L = struct.unpack_from("<I", c, p)[0]; qq = p + 4
        while qq < p + L:
            b = pb(qq)
            if b["id"] == 0x12 and blen(b["type"]) < 0:
                r = b["dataoff"] + 4; ds = {}
                while r < b["end"]:
                    x = pb(r); ds[x["id"]] = x["data"]; r = x["end"]
                docsize = (ds.get(1, 0) / EMU, ds.get(2, 0) / EMU)
            elif b["id"] == 2 and blen(b["type"]) < 0:
                r = b["dataoff"] + 4
                while r < b["end"]:
                    x = pb(r)
                    if x["id"] == 0: pagelist.append(x["data"])
                    r = x["end"]
            qq = b["end"]
pages = {}
for ch in chunks:
    if ch["type"] == 0x43:
        p = ch["off"]; L = struct.unpack_from("<I", c, p)[0]; qq = p + 4; lst = []; master = None
        while qq < p + L:
            b = pb(qq)
            if b["id"] == 2 and blen(b["type"]) < 0:
                r = b["dataoff"] + 4
                while r < b["end"]:
                    x = pb(r)
                    if x["type"] == 0x70: lst.append(x["data"])
                    r = x["end"]
            if b["id"] == 0xe: master = "master"
            qq = b["end"]
        pages[ch["seq"]] = lst

W, H = (docsize or (1260, 828))
DX, DY = W / 2 - 18, H / 2 - 18   # printed page is 0.25in inside the document page
out_pages = []
for pid in pagelist:
    lst = pages.get(pid)
    if not lst: continue
    items = []
    for s in lst:
        sh = shapes.get(s, {}); dd = det.get(s, {}); pr = sh.get("props", {})
        box = sh.get("box")
        if box is None and sh.get("child") and sh.get("group") in shapes:
            g = shapes[sh["group"]]; gb = g.get("box"); gr = g.get("spgr")
            if gb and gr and gr[2] - gr[0]:
                sx = (gb[2] - gb[0]) / (gr[2] - gr[0]); sy = (gb[3] - gb[1]) / (gr[3] - gr[1]); cb = sh["child"]
                box = [gb[0] + (cb[0] - gr[0]) * sx, gb[1] + (cb[1] - gr[1]) * sy, gb[0] + (cb[2] - gr[0]) * sx, gb[1] + (cb[3] - gr[1]) * sy]
        pdf = [round(box[0] + DX, 1), round(box[1] + DY, 1), round(box[2] + DX, 1), round(box[3] + DY, 1)] if box else None
        onpage = pdf and pdf[2] > -10 and pdf[0] < W and pdf[3] > -10 and pdf[1] < H
        pib = pr.get(0x104); blip = blipfiles.get(pib_to_rec.get(pib)) if pib else None
        crop = [round(((pr.get(k, 0) if pr.get(k, 0) < (1 << 31) else pr.get(k) - (1 << 32)) / 65536), 4) for k in (0x100, 0x101, 0x102, 0x103)]
        def col(v): return "%06x" % (((v & 0xFF) << 16) | (v & 0xFF00) | ((v >> 16) & 0xFF)) if v is not None else None  # BGR -> RGB
        fill_used = bool(pr.get(0x1BF, 0) & 0x10) if 0x1BF in pr else None
        items.append(dict(seq=s, shape_type=sh.get("st"), group=sh.get("group"), is_group=sh.get("is_group_leader"), box_pdf=pdf, on_page=bool(onpage),
                          w=dd.get("w"), h=dd.get("h"), text_id=dd.get("text"), picture=blip, pib=pib, crop_tblr=crop,
                          fill=col(pr.get(0x181)), fill_on=fill_used, line=col(pr.get(0x1C0)), line_w=(pr.get(0x1CB, 12700) / EMU),
                          line_flags=pr.get(0x1FF), rotation=(pr.get(0x4, 0) / 65536), cols=pr.get(0x8C)))
    # also list children of on-page groups
    out_pages.append(dict(page_id=pid, shapes=items))
json.dump(dict(docsize_pt=[W, H], pages=out_pages), open(os.path.join(out, "pages.json"), "w"), indent=1)
print("stories", len(stories), "blips", len(blipfiles), "pages", [(p["page_id"], len(p["shapes"])) for p in out_pages], "docsize", W, H)
