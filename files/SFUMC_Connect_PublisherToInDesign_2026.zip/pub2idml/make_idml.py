#!/usr/bin/env python3
"""Build an InDesign IDML package for the Sept 13, 2026 SFUMC bulletin ("The Way")
from the geometry and text decoded out of the Publisher file."""
import json, os, re, zipfile, html, sys
from PIL import Image

OUT_DIR = sys.argv[1] if len(sys.argv) > 1 else "build"
IDML_NAME = sys.argv[2] if len(sys.argv) > 2 else "Bulletin - 2026-09-13 - Wells We Didn't Dig.idml"
LINKS_DIR = os.path.join(OUT_DIR, "Links")
import urllib.parse
LINK_URI_BASE = "file:" + urllib.parse.quote(os.path.abspath(LINKS_DIR))

PAGE_W, PAGE_H = 1224.0, 792.0          # 17 x 11 in
DX, DY = -PAGE_W / 2, -PAGE_H / 2       # page -> spread coordinates
DOM = "15.0"
NS = 'xmlns:idPkg="http://ns.adobe.com/AdobeInDesign/idml/1.0/packaging"'
HDR = '<?xml version="1.0" encoding="UTF-8" standalone="yes"?>\n'

stories = json.load(open("stories.json"))

# ------------------------------------------------------------------ colours
COLORS = {
    "Navy": (51, 64, 87),
    "Bulletin Red": (232, 29, 44),
    "Rule Red": (192, 0, 0),
    "Link Blue": (0, 102, 255),
    "Frame Gray": (89, 89, 89),
}

# ------------------------------------------------------------------ styles
CG = "Century Gothic"
NS_FONT = "New Spirit"

def tabs(*stops):
    items = "".join(
        f'<ListItem type="record"><Alignment type="enumeration">{al}</Alignment>'
        f'<AlignmentCharacter type="string">.</AlignmentCharacter><Leader type="string"></Leader>'
        f'<Position type="unit">{pos}</Position></ListItem>' for al, pos in stops)
    return f'<TabList type="list">{items}</TabList>'

# name -> (attrs dict, extra properties xml)
PSTYLES = {
    "Worship Item": (dict(font=CG, style="Bold", size=11, color="Color/Navy", leading=13.2, before=10.8), tabs(("RightAlign", 370.4))),
    "Worship Item Contemporary": (dict(font=CG, style="Bold", size=11, color="Color/Navy", leading=13.2, before=21), tabs(("RightAlign", 370.4))),
    "Liturgy Leader": (dict(font=CG, style="Regular", size=8, color="Color/Black", leading=10.1, before=0), ""),
    "Liturgy People": (dict(font=CG, style="Bold", size=8, color="Color/Black", leading=10.1, before=0), ""),
    "Worship Body": (dict(font=CG, style="Regular", size=8.5, color="Color/Black", leading=12.75, before=0), ""),
    "Worship Body Contemporary": (dict(font=CG, style="Regular", size=10, color="Color/Black", leading=15, before=0), ""),
    "Credit Line": (dict(font=CG, style="Italic", size=9, color="Color/Black", leading=10.8, before=0, just="RightAlign"), ""),
    "Stand Note": (dict(font=CG, style="Italic", size=9, color="Color/Black", leading=10.8, before=24), ""),
    "Panel Note": (dict(font=CG, style="Bold", size=14, color="Color/Navy", leading=16.8, before=0, just="CenterAlign", tracking=60), ""),
    "Footer Note": (dict(font=CG, style="Bold", size=7.4, color="Color/Black", leading=15.9, before=0, just="CenterAlign"), ""),
    "Calendar Day": (dict(font=CG, style="Bold", size=9, color="Color/Navy", leading=15.3, before=13), ""),
    "Calendar Entry": (dict(font=CG, style="Regular", size=8.5, color="Color/Black", leading=15.3, before=0), tabs(("RightAlign", 46), ("LeftAlign", 54), ("LeftAlign", 72))),
    "Calendar See More": (dict(font=CG, style="Bold", size=7.6, color="Color/Bulletin Red", leading=15.3, before=8, left=7), ""),
    "Calendar Upcoming Head": (dict(font=CG, style="Bold", size=9, color="Color/Bulletin Red", leading=15.3, before=0), ""),
    "Calendar Upcoming": (dict(font=CG, style="Regular", size=8.5, color="Color/Black", leading=16.4, before=0), ""),
    "Staff Name": (dict(font=CG, style="Bold", size=8, color="Color/Navy", leading=9.5, before=9.7), ""),
    "Staff Title": (dict(font=CG, style="Regular", size=7, color="Color/Black", leading=8.4, before=0), ""),
    "Staff Email": (dict(font=CG, style="Regular", size=7, color="Color/Link Blue", leading=8.4, before=0, underline=True), ""),
    "Giving Lead": (dict(font=CG, style="Bold", size=9, color="Color/Black", leading=12.75, before=0, left=4.4, first=-4.4), ""),
    "Giving Item": (dict(font=CG, style="Regular", size=8.5, color="Color/Black", leading=12.75, before=0, left=4.4, first=-4.4), ""),
    "Tax Note": (dict(font=CG, style="Italic", size=7, color="Color/Black", leading=10.6, before=0, just="CenterAlign"), ""),
    "Welcome Box": (dict(font=NS_FONT, style="Regular", size=34, color="Color/Paper", leading=34, before=0, just="CenterAlign"), ""),
    "Scan Text": (dict(font=CG, style="Regular", size=11, color="Color/Paper", leading=14.5, before=0), ""),
    "Attendance Head": (dict(font=CG, style="Bold", size=12, color="Color/Paper", leading=14.4, before=6, just="CenterAlign", caps=True), ""),
    "Attendance Value": (dict(font=CG, style="Regular", size=12, color="Color/Paper", leading=14.4, before=0, just="CenterAlign"), ""),
    "Attendance Social": (dict(font=CG, style="Regular", size=9, color="Color/Paper", leading=11, before=10, just="CenterAlign"), ""),
    "Cover Welcome": (dict(font=NS_FONT, style="Regular", size=48, color="Color/Paper", leading=48, before=0, just="CenterAlign"), ""),
    "Cover Welcome Navy": (dict(font=NS_FONT, style="Regular", size=48, color="Color/Navy", leading=48, before=0, just="CenterAlign"), ""),
    "Cover Date Navy": (dict(font=CG, style="Regular", size=14, color="Color/Navy", leading=16.8, before=0, just="CenterAlign", tracking=150), ""),
    "Cover Date": (dict(font=CG, style="Regular", size=14, color="Color/Paper", leading=16.8, before=0, just="CenterAlign", tracking=150), ""),
}

CSTYLES = {
    "Asterisk Red": dict(font=CG, style="Bold", size=12, color="Color/Bulletin Red"),
    "Asterisk Navy": dict(font=CG, style="Bold", size=12, color="Color/Navy"),
    "Detail Bold": dict(font=CG, style="Bold", size=10, color="Color/Black"),
    "Credit": dict(font=CG, style="Italic", size=9, color="Color/Black"),
    "Bold": dict(style="Bold"),
    "Bold Caps": dict(style="Bold", caps=True),
    "Link": dict(color="Color/Link Blue", underline=True),
    "Underline": dict(underline=True),
    "Red Bar": dict(color="Color/Bulletin Red"),
}

def style_attrs(a):
    s = []
    if "style" in a: s.append(f'FontStyle="{a["style"]}"')
    if "size" in a: s.append(f'PointSize="{a["size"]}"')
    if "color" in a: s.append(f'FillColor="{a["color"]}"')
    if "before" in a: s.append(f'SpaceBefore="{a["before"]}"')
    if "just" in a: s.append(f'Justification="{a["just"]}"')
    if "tracking" in a: s.append(f'Tracking="{a["tracking"]}"')
    if "left" in a: s.append(f'LeftIndent="{a["left"]}"')
    if "first" in a: s.append(f'FirstLineIndent="{a["first"]}"')
    if a.get("underline"): s.append('Underline="true"')
    if a.get("caps"): s.append('Capitalization="AllCaps"')
    return " ".join(s)

def style_props(a, based):
    p = f'<BasedOn type="string">{based}</BasedOn>'
    if "font" in a: p += f'<AppliedFont type="string">{a["font"]}</AppliedFont>'
    if "leading" in a: p += f'<Leading type="unit">{a["leading"]}</Leading>'
    return p

def styles_xml():
    cs = ['<CharacterStyle Self="CharacterStyle/$ID/[No character style]" Name="$ID/[No character style]"/>']
    for n, a in CSTYLES.items():
        cs.append(f'<CharacterStyle Self="CharacterStyle/{html.escape(n)}" Name="{html.escape(n)}" {style_attrs(a)}>'
                  f'<Properties>{style_props(a, "$ID/[No character style]")}</Properties></CharacterStyle>')
    ps = ['<ParagraphStyle Self="ParagraphStyle/$ID/[No paragraph style]" Name="$ID/[No paragraph style]" '
          'FillColor="Color/Black" FontStyle="Regular" PointSize="12"><Properties>'
          f'<AppliedFont type="string">{CG}</AppliedFont></Properties></ParagraphStyle>',
          '<ParagraphStyle Self="ParagraphStyle/$ID/NormalParagraphStyle" Name="$ID/NormalParagraphStyle">'
          '<Properties><BasedOn type="string">$ID/[No paragraph style]</BasedOn></Properties></ParagraphStyle>']
    for n, (a, extra) in PSTYLES.items():
        ps.append(f'<ParagraphStyle Self="ParagraphStyle/{html.escape(n)}" Name="{html.escape(n)}" {style_attrs(a)}>'
                  f'<Properties>{style_props(a, "$ID/NormalParagraphStyle")}{extra}</Properties></ParagraphStyle>')
    return (HDR + f'<idPkg:Styles {NS} DOMVersion="{DOM}">'
            f'<RootCharacterStyleGroup Self="rcsg">{"".join(cs)}</RootCharacterStyleGroup>'
            f'<RootParagraphStyleGroup Self="rpsg">{"".join(ps)}</RootParagraphStyleGroup>'
            '<RootObjectStyleGroup Self="rosg">'
            '<ObjectStyle Self="ObjectStyle/$ID/[None]" Name="$ID/[None]"/>'
            '<ObjectStyle Self="ObjectStyle/$ID/[Normal Graphics Frame]" Name="$ID/[Normal Graphics Frame]"/>'
            '<ObjectStyle Self="ObjectStyle/$ID/[Normal Text Frame]" Name="$ID/[Normal Text Frame]"/>'
            '<ObjectStyle Self="ObjectStyle/$ID/[Normal Grid]" Name="$ID/[Normal Grid]"/>'
            '</RootObjectStyleGroup>'
            '<RootTableStyleGroup Self="rtsg"><TableStyle Self="TableStyle/$ID/[No table style]" Name="$ID/[No table style]"/>'
            '<TableStyle Self="TableStyle/$ID/[Basic Table]" Name="$ID/[Basic Table]"/></RootTableStyleGroup>'
            '<RootCellStyleGroup Self="rcelsg"><CellStyle Self="CellStyle/$ID/[None]" Name="$ID/[None]"/></RootCellStyleGroup>'
            '</idPkg:Styles>')

def graphic_xml():
    x = [HDR, f'<idPkg:Graphic {NS} DOMVersion="{DOM}">',
         '<Color Self="Color/Black" Model="Process" Space="CMYK" ColorValue="0 0 0 100" ColorOverride="Specialblack" AlternateSpace="NoAlternateColor" AlternateColorValue="" Name="Black" ColorEditable="false" ColorRemovable="false" Visible="true" SwatchCreatorID="7937"/>',
         '<Color Self="Color/Paper" Model="Process" Space="CMYK" ColorValue="0 0 0 0" ColorOverride="Specialpaper" AlternateSpace="NoAlternateColor" AlternateColorValue="" Name="Paper" ColorEditable="true" ColorRemovable="false" Visible="true" SwatchCreatorID="7937"/>',
         '<Color Self="Color/Registration" Model="Registration" Space="CMYK" ColorValue="100 100 100 100" ColorOverride="Specialregistration" AlternateSpace="NoAlternateColor" AlternateColorValue="" Name="Registration" ColorEditable="false" ColorRemovable="false" Visible="true" SwatchCreatorID="7937"/>']
    for n, (r, g, b) in COLORS.items():
        x.append(f'<Color Self="Color/{html.escape(n)}" Model="Process" Space="RGB" ColorValue="{r} {g} {b}" ColorOverride="Normal" AlternateSpace="NoAlternateColor" AlternateColorValue="" Name="{html.escape(n)}" ColorEditable="true" ColorRemovable="true" Visible="true" SwatchCreatorID="7937"/>')
    x.append('<Swatch Self="Swatch/None" Name="None" ColorEditable="false" ColorRemovable="false" Visible="true" SwatchCreatorID="7937"/>')
    x.append('<StrokeStyle Self="StrokeStyle/$ID/Solid" Name="$ID/Solid"/>')
    x.append('</idPkg:Graphic>')
    return "".join(x)

def fonts_xml():
    fams = {CG: [("Regular", "CenturyGothic"), ("Bold", "CenturyGothic-Bold"), ("Italic", "CenturyGothic-Italic"), ("Bold Italic", "CenturyGothic-BoldItalic")],
            NS_FONT: [("Regular", "NewSpirit-Regular"), ("Medium", "NewSpirit-Medium")]}
    x = [HDR, f'<idPkg:Fonts {NS} DOMVersion="{DOM}">']
    for i, (fam, styles) in enumerate(fams.items()):
        x.append(f'<FontFamily Self="ff{i}" Name="{fam}">')
        for j, (st, ps) in enumerate(styles):
            x.append(f'<Font Self="ff{i}f{j}" FontFamily="{fam}" Name="{fam} {st}" PostScriptName="{ps}" Status="Installed" FontStyleName="{st}" FontType="TrueType" WritingScript="0" FullName="{fam} {st}" FullNameNative="{fam} {st}" FontStyleNameNative="{st}" PlatformName="$ID/" Version="1.0" TypekitID="$ID/"/>')
        x.append('</FontFamily>')
    x.append('</idPkg:Fonts>')
    return "".join(x)

def prefs_xml():
    return (HDR + f'<idPkg:Preferences {NS} DOMVersion="{DOM}">'
            f'<DocumentPreference PageHeight="{PAGE_H}" PageWidth="{PAGE_W}" FacingPages="false" '
            'DocumentBleedTopOffset="0" DocumentBleedBottomOffset="0" DocumentBleedInsideOrLeftOffset="0" DocumentBleedOutsideOrRightOffset="0" '
            'DocumentBleedUniformSize="true" SlugTopOffset="0" SlugBottomOffset="0" SlugInsideOrLeftOffset="0" SlugRightOrOutsideOffset="0" '
            'DocumentSlugUniformSize="false" PreserveLayoutWhenShuffling="true" AllowPageShuffle="true" OverprintBlack="true" '
            'PageBinding="LeftToRight" ColumnGuideColor="Violet" MarginGuideColor="Magenta" ColumnGuideLocked="true" '
            'MasterTextFrame="false" StartPageNumber="1" PageOrientation="Landscape" PageSize="Tabloid" CreatePrimaryTextFrame="false" '
            'SnippetImportUsesOriginalLocation="false" IntentDrop="PrintIntent"/>'
            '<ViewPreference HorizontalMeasurementUnits="Inches" VerticalMeasurementUnits="Inches" RulerOrigin="PageOrigin" '
            'ShowRulers="true" TextSizeMeasurementUnits="Points" TypographicMeasurementUnits="Points" LineMeasurementUnits="Points" '
            'StrokeMeasurementUnits="Points" PointsPerInch="72" KeyboardIncrementValue="1" CursorKeyIncrement="1" '
            'HorizontalCustomPoints="12" VerticalCustomPoints="12"/>'
            '</idPkg:Preferences>')

# ------------------------------------------------------------------ geometry helpers
uid = [1000]
def nid(prefix="u"):
    uid[0] += 1
    return f"{prefix}{uid[0]}"

def path_geometry(x0, y0, x1, y1):
    x0, x1, y0, y1 = x0 + DX, x1 + DX, y0 + DY, y1 + DY
    pts = [(x0, y0), (x0, y1), (x1, y1), (x1, y0)]
    arr = "".join(f'<PathPointType Anchor="{x:.3f} {y:.3f}" LeftDirection="{x:.3f} {y:.3f}" RightDirection="{x:.3f} {y:.3f}"/>' for x, y in pts)
    return f'<PathGeometry><GeometryPathType PathOpen="false"><PathPointArray>{arr}</PathPointArray></GeometryPathType></PathGeometry>'

def rect_item(box, fill="Swatch/None", stroke="Swatch/None", sw=0, name=""):
    x0, y0, x1, y1 = box
    return (f'<Rectangle Self="{nid()}" ContentType="Unassigned" StoryTitle="$ID/" Name="{html.escape(name)}" Visible="true" Locked="false" '
            f'ItemLayer="ua" FillColor="{fill}" StrokeColor="{stroke}" StrokeWeight="{sw}" ItemTransform="1 0 0 1 0 0" '
            f'AppliedObjectStyle="ObjectStyle/$ID/[None]"><Properties>{path_geometry(x0, y0, x1, y1)}</Properties></Rectangle>')

def image_item(box, filename, crop=(0, 0, 0, 0), stroke="Swatch/None", sw=0, name=""):
    """box in page points; crop = (top, bottom, left, right) fractions of the image hidden."""
    x0, y0, x1, y1 = box
    fw, fh = x1 - x0, y1 - y0
    im = Image.open(os.path.join(LINKS_DIR, filename))
    pw, ph = im.size
    t, b, l, r = crop
    sx = fw / (pw * (1 - l - r))
    sy = fh / (ph * (1 - t - b))
    tx = (x0 + DX) - l * pw * sx
    ty = (y0 + DY) - t * ph * sy
    fmt = "$ID/Portable Network Graphics (PNG)" if filename.lower().endswith(".png") else "$ID/JPEG"
    uri = html.escape(LINK_URI_BASE + "/" + urllib.parse.quote(filename))
    img = (f'<Image Self="{nid()}" ItemTransform="{sx:.6f} 0 0 {sy:.6f} {tx:.3f} {ty:.3f}" Space="$ID/#Links_RGB" ActualPpi="72 72" EffectivePpi="{72/sx:.0f} {72/sy:.0f}" '
           f'ImageTypeName="{fmt}" Name="$ID/" Visible="true" LocalDisplaySetting="Default" ImageRenderingIntent="UseColorSettings" AppliedObjectStyle="ObjectStyle/$ID/[None]" ItemLayer="ua">'
           f'<Properties><Profile type="string">$ID/Embedded</Profile><GraphicBounds Left="0" Top="0" Right="{pw}" Bottom="{ph}"/></Properties>'
           f'<Link Self="{nid()}" AssetURL="$ID/" AssetID="$ID/" LinkResourceURI="{uri}" LinkResourceFormat="{fmt}" StoredState="Normal" '
           'LinkClassID="35906" LinkClientID="257" LinkResourceModified="false" LinkObjectModified="false" ShowInUI="true" CanEmbed="true" '
           'CanUnembed="true" CanPackage="true" ImportPolicy="NoAutoImport" ExportPolicy="NoAutoExport" LinkImportStamp="file 0 0" '
           'LinkImportModificationTime="2026-09-08T12:00:00" LinkImportTime="2026-09-08T12:00:00"/></Image>')
    return (f'<Rectangle Self="{nid()}" ContentType="GraphicType" StoryTitle="$ID/" Name="{html.escape(name)}" Visible="true" Locked="false" '
            f'ItemLayer="ua" FillColor="Swatch/None" StrokeColor="{stroke}" StrokeWeight="{sw}" ItemTransform="1 0 0 1 0 0" '
            f'AppliedObjectStyle="ObjectStyle/$ID/[Normal Graphics Frame]"><Properties>{path_geometry(x0, y0, x1, y1)}</Properties>'
            f'<FrameFittingOption LeftCrop="0" TopCrop="0" RightCrop="0" BottomCrop="0" FittingOnEmptyFrame="None" FittingAlignment="CenterAnchor"/>'
            f'{img}</Rectangle>')

story_files = {}
def text_frame(box, paragraphs, vjust="TopAlign", inset=2.88, name="", columns=1, gutter=12):
    sid = nid("s")
    x0, y0, x1, y1 = box
    story_files[sid] = story_xml(sid, paragraphs)
    return (f'<TextFrame Self="{nid()}" ParentStory="{sid}" PreviousTextFrame="n" NextTextFrame="n" ContentType="TextType" '
            f'StoryTitle="$ID/" Name="{html.escape(name)}" Visible="true" Locked="false" ItemLayer="ua" FillColor="Swatch/None" '
            f'StrokeColor="Swatch/None" StrokeWeight="0" ItemTransform="1 0 0 1 0 0" AppliedObjectStyle="ObjectStyle/$ID/[Normal Text Frame]">'
            f'<Properties>{path_geometry(x0, y0, x1, y1)}</Properties>'
            f'<TextFramePreference TextColumnCount="{columns}" TextColumnGutter="{gutter}" TextColumnFixedWidth="{(x1-x0-2*inset-(columns-1)*gutter)/columns:.3f}" '
            f'UseFixedColumnWidth="false" VerticalJustification="{vjust}" AutoSizingType="Off" IgnoreWrap="true" FirstBaselineOffset="AscentOffset">'
            f'<Properties><InsetSpacing type="list"><ListItem type="unit">{inset}</ListItem><ListItem type="unit">{inset}</ListItem>'
            f'<ListItem type="unit">{inset}</ListItem><ListItem type="unit">{inset}</ListItem></InsetSpacing></Properties></TextFramePreference>'
            f'</TextFrame>')

def esc(t):
    return html.escape(t, quote=False).replace("\t", "&#9;")

def story_xml(sid, paragraphs):
    """paragraphs: list of (paragraph style, runs); runs: list of (char style or None, text)."""
    out = [HDR, f'<idPkg:Story {NS} DOMVersion="{DOM}">',
           f'<Story Self="{sid}" AppliedTOCStyle="n" TrackChanges="false" StoryTitle="$ID/" AppliedNamedGrid="n">',
           '<StoryPreference OpticalMarginAlignment="false" OpticalMarginSize="12" FrameType="TextFrameType" StoryOrientation="Horizontal" StoryDirection="LeftToRightDirection"/>',
           '<InCopyExportOption IncludeGraphicProxies="true" IncludeAllResources="false"/>']
    n = len(paragraphs)
    for i, (pstyle, runs) in enumerate(paragraphs):
        out.append(f'<ParagraphStyleRange AppliedParagraphStyle="ParagraphStyle/{html.escape(pstyle)}">')
        if not runs:
            runs = [(None, "")]
        for j, (cstyle, text) in enumerate(runs):
            cs = f"CharacterStyle/{html.escape(cstyle)}" if cstyle else "CharacterStyle/$ID/[No character style]"
            br = "<Br/>" if (j == len(runs) - 1 and i < n - 1) else ""
            out.append(f'<CharacterStyleRange AppliedCharacterStyle="{cs}"><Content>{esc(text)}</Content>{br}</CharacterStyleRange>')
        out.append('</ParagraphStyleRange>')
    out.append('</Story></idPkg:Story>')
    return "".join(out)

# ------------------------------------------------------------------ text preparation
def paras_of(tid):
    return [p.replace("\xa0", " ") for p in stories[str(tid)].split("\r")]

CREDIT_RE = re.compile(r"^(Brandon Marcus|Worship Band|Philip Poole|Liturgist:.*|Rev\. .*|.*Marcus and .*)$")

def order_of_worship(tid, contemporary):
    item_style = "Worship Item Contemporary" if contemporary else "Worship Item"
    body_style = "Worship Body Contemporary" if contemporary else "Worship Body"
    ast = "Asterisk Navy" if contemporary else "Asterisk Red"
    out = []
    for raw in paras_of(tid):
        line = raw.replace(" ", " ").rstrip()
        core = line.strip()
        if not core or re.fullmatch(r"[-=\s]*", core):
            continue
        if core.startswith("L:"):
            out.append(("Liturgy Leader", [(None, re.sub(r"\s{2,}", " ", core))])); continue
        if core.startswith("P:"):
            out.append(("Liturgy People", [(None, re.sub(r"\s{2,}", " ", core))])); continue
        if core.startswith("All children") or core.startswith("You may pray"):
            out.append((body_style, [(None, re.sub(r"\s{2,}", " ", core))])); continue
        if core.startswith("*Please stand"):
            out.append(("Stand Note", [(ast, "*"), (None, core[1:])])); continue
        # credit-only continuation line (leading tabs/spaces, then a name)
        if re.match(r"^[\t ]", line) and CREDIT_RE.match(core):
            out.append(("Credit Line", [(None, core)])); continue
        m = re.match(r"^(\*?)(.*?)(?:[\t ]{2,}|\t)(\S.*)$", line.strip("\t ") if not line.startswith("*") else line)
        if m and m.group(3).strip():
            star, label, detail = m.group(1), m.group(2).strip(), m.group(3).strip()
            detail = re.sub(r"\s{2,}", " ", detail).replace("~", "~")
            runs = []
            if star: runs.append((ast, "*"))
            runs.append((None, label))
            dstyle = "Credit" if CREDIT_RE.match(detail) else "Detail Bold"
            runs.append((dstyle, "\t" + detail))
            out.append((item_style, runs))
        else:
            label = core
            runs = []
            if label.startswith("*"):
                runs.append((ast, "*")); label = label[1:].strip()
            runs.append((None, label))
            out.append((item_style, runs))
    return out

def calendar(tid):
    out = []
    for raw in paras_of(tid):
        line = raw.rstrip()
        core = line.strip()
        if not core:
            continue
        m = re.match(r"^([A-Z]+DAY)\|(.+)$", core)
        if m:
            out.append(("Calendar Day", [("Underline", m.group(1)), ("Red Bar", "|"), ("Underline", m.group(2).strip())])); continue
        m = re.match(r"^\s*(\d{1,2}:\d{2} [ap]\.m\.)\s*\t\s*(.*)$", line)
        if m:
            out.append(("Calendar Entry", [(None, "\t" + m.group(1) + "\t" + m.group(2).strip())])); continue
        if core.startswith("~see"):
            out.append(("Calendar See More", [(None, core)])); continue
        if core.startswith("UPCOMING"):
            out.append(("Calendar Upcoming Head", [(None, core)])); continue
        if re.match(r"^\d{1,2}/\d{1,2} \|", core):
            out.append(("Calendar Upcoming", [(None, core)])); continue
        if core.startswith("No events"):
            out.append(("Calendar Entry", [(None, "\t\t" + core)])); continue
        if line.startswith("\t"):
            out.append(("Calendar Entry", [(None, "\t\t\t" + core)])); continue
        out.append(("Calendar Entry", [(None, core)]))
    return out

def staff(tid):
    left, right = [], []
    blocks, cur = [], []
    for raw in paras_of(tid):
        line = raw.strip()
        if re.fullmatch(r"[-\s]*", line):
            if cur: blocks.append(cur); cur = []
            continue
        cur.append(line)
    if cur: blocks.append(cur)
    for i, b in enumerate(blocks):
        target = right if b[0].startswith("Erin Tucker") or (right and True) else left
        target.append(("Staff Name", [(None, b[0])]))
        for l in b[1:]:
            target.append(("Staff Email" if "@" in l else "Staff Title", [(None, l)]))
    return left, right

def giving(tid):
    out = []
    for i, raw in enumerate(paras_of(tid)):
        line = raw.strip()
        if not line: continue
        line = line.replace("\t", " ")
        if i == 0:
            m = re.match(r"^(.*?visit\s+)(\S+)\s*$", line)
            if m: out.append(("Giving Lead", [(None, m.group(1)), ("Link", m.group(2))]))
            else: out.append(("Giving Lead", [(None, line)]))
        else:
            m = re.match(r"^(.*?)(finance@spanishfortumc\.org)(.*)$", line)
            if m: out.append(("Giving Item", [(None, m.group(1)), ("Link", m.group(2)), (None, m.group(3))]))
            else: out.append(("Giving Item", [(None, line)]))
    return out

def attendance(tid):
    out = []
    for raw in paras_of(tid):
        line = raw.strip()
        if not line: continue
        if line.lower().startswith(("attendance", "sunday average")):
            out.append(("Attendance Head", [(None, line)]))
        elif line.startswith("Giving:"):
            out.append(("Attendance Value", [("Bold Caps", "Giving:"), (None, line[7:])]))
        elif line.startswith("Facebook") or re.match(r"^[\d.]+$", line):
            out.append(("Attendance Social", [(None, line)]))
        else:
            out.append(("Attendance Value", [(None, line)]))
    return out

def simple(tid, style, drop_blank=True):
    return [(style, [(None, p.strip())]) for p in paras_of(tid) if p.strip() or not drop_blank]

# ------------------------------------------------------------------ pages
NAVY, RULE_RED, GRAY = "Color/Navy", "Color/Rule Red", "Color/Frame Gray"
BAR_CROP = (0, 0, 0, 0.2475)

trad = order_of_worship(2488, False)
if not any(p[0] == "Stand Note" for p in trad):
    trad.append(("Stand Note", [("Asterisk Red", "*"), (None, "Please stand as able.")]))
contemp = order_of_worship(2487, True)

# ---- edits requested Sept 8, 2026
def _fix_title(paras):
    return [(st, [(cs, t.replace("Wells We...", "Wells We Didn't Dig")) for cs, t in runs]) for st, runs in paras]
trad = _fix_title(trad); contemp = _fix_title(contemp)
def _insert_after(paras, startswith, new):
    out = []
    for p in paras:
        out.append(p)
        label = "".join(t for cs, t in p[1] if cs not in ("Asterisk Red", "Asterisk Navy")).strip()
        if label.startswith(startswith):
            out.append(new)
    return out
trad = _insert_after(trad, "Glory Be to the Father", ("Worship Item", [(None, "Celebration of Grandparents and Primetimer's Ministry")]))
contemp = _insert_after(contemp, "Opening Music", ("Worship Item Contemporary", [(None, "Celebration of Grandparents and Primetimer's Ministry")]))
contemp = [(st, [(cs, t.replace("Welcome and Passing the Peace of Christ", "Welcome")) for cs, t in runs]) for st, runs in contemp]
contemp = _insert_after(contemp, "You may pray at the altar", ("Worship Item Contemporary", [("Asterisk Navy", "*"), (None, "Passing the Peace of Christ")]))
trad = _insert_after(trad, "Closing Hymn", ("Worship Item", [(None, "Recognition of Leadership"), ("Credit", "\tAsher and Sandra Carmichael")]))

page1 = [
    image_item((17.4, 18.2, 392.4, 43.6), "bar_traditional_845.png", BAR_CROP, name="Traditional header bar"),
    image_item((432.4, 18.1, 807.4, 43.6), "bar_contemporary_1100.png", BAR_CROP, name="Contemporary header bar"),
    image_item((843.3, 18.0, 1218.3, 43.5), "bar_worship_serve_connect_grow.png", BAR_CROP, name="Panel header bar"),
    rect_item((823.2, 18.1, 826.8, 792.0), fill=RULE_RED, name="Red panel rule"),
    rect_item((19.6, 723.3, 800.1, 726.9), fill=NAVY, name="Footer rule"),
    image_item((843.6, 59.8, 1199.0, 259.8), "announcement_1_top_childrens_choir.png", stroke=GRAY, sw=0.75, name="Announcement 1"),
    image_item((844.0, 278.4, 1199.4, 478.4), "announcement_2_middle_hour_or_sew.png", stroke=GRAY, sw=0.75, name="Announcement 2"),
    image_item((843.6, 496.5, 1199.9, 696.9), "announcement_3_bottom_thursday_bible_study.jpg", stroke=GRAY, sw=0.75, name="Announcement 3"),
    text_frame((16.2, 56.5, 392.4, 726.9), trad, name="Traditional order of worship"),
    text_frame((430.8, 55.2, 807.0, 737.1), contemp, name="Contemporary order of worship"),
    text_frame((842.4, 56.5, 1202.7, 780.9), [("Panel Note", [(None, "FOR MORE DETAILS ON THESE, AND OTHER\u2028EVENTS, PLEASE GO TO\u2028WWW.SPANISHFORTUMC.ORG/INFO.")])], vjust="BottomAlign", name="Panel note"),
    text_frame((21.0, 730.2, 800.1, 774.0), simple(2485, "Footer Note"), name="Footer"),
]

staff_left, staff_right = staff(194)
page2 = [
    text_frame((18.0, 18.0, 392.8, 668.0), calendar(2388), name="Calendar"),
    image_item((18.0, 673.4, 392.8, 784.7), "prayer_request_box.jpg", (0.4719, 0, 0, 0), name="Prayer request"),
    image_item((421.8, 17.7, 798.6, 43.3), "bar_church_staff.png", (0, 0, 0, 0.2482), name="Church staff bar"),
    text_frame((440.0, 52.9, 627.5, 304.4), staff_left, name="Staff left"),
    text_frame((628.0, 52.9, 815.5, 304.4), staff_right, name="Staff right"),
    rect_item((421.8, 309.2, 798.0, 312.8), fill=NAVY, name="Rule"),
    rect_item((423.9, 509.0, 800.1, 512.6), fill=NAVY, name="Rule"),
    image_item((447.7, 317.4, 776.3, 386.9), "online_giving_header.png", (0.3864, 0.3367, 0.1318, 0.132), name="Online Giving header"),
    image_item((447.7, 386.9, 533.0, 471.5), "qr_giving.png", (0.037, 0.0508, 0.0431, 0.037), name="QR giving"),
    text_frame((537.1, 385.1, 787.7, 507.2), giving(2090), name="Giving instructions"),
    text_frame((422.1, 480.1, 796.3, 509.0), simple(2091, "Tax Note"), name="Tax note"),
    rect_item((423.9, 516.0, 800.1, 603.1), fill=NAVY, name="Welcome box"),
    text_frame((451.1, 516.0, 725.7, 560.4), [("Welcome Box", [(None, "Welcome")])], name="Welcome"),
    text_frame((442.1, 560.4, 716.7, 608.9), [("Scan Text", [("Bold", "Scan the QR code"), (None, " to visit our website and connect to our email lists, events, and more!")])], name="Scan text"),
    image_item((707.0, 524.8, 776.3, 593.2), "qr_website.png", (0.006, 0.006, 0, 0), name="QR website"),
    rect_item((421.8, 616.3, 798.7, 784.8), fill=RULE_RED, name="Attendance box"),
    text_frame((421.8, 620.8, 798.7, 777.4), attendance(2390), vjust="CenterAlign", name="Attendance"),
    image_item((843.0, 0.0, 1195.2, 792.0), "cover_wells_rack_card.png", name="Cover art"),
    image_item((850.0, 18.0, 960.0, 75.3), "logo_sfumc_navy.png", name="Logo"),
    text_frame((826.3, 292.0, 1212.0, 360.0), [("Cover Welcome Navy", [(None, "Welcome")])], name="Cover welcome"),
    text_frame((826.2, 362.0, 1212.0, 394.0), simple(1254, "Cover Date Navy"), name="Cover date"),
]

def spread_xml(self_id, page_num, items):
    return (HDR + f'<idPkg:Spread {NS} DOMVersion="{DOM}">'
            f'<Spread Self="{self_id}" FlattenerOverride="Default" AllowPageShuffle="true" ItemTransform="1 0 0 1 0 0" ShowMasterItems="true" '
            'PageCount="1" BindingLocation="0" PageTransitionType="None" PageTransitionDirection="NotApplicable" PageTransitionDuration="Medium">'
            f'<Page Self="{self_id}p" Name="{page_num}" AppliedTrapPreset="TrapPreset/$ID/kDefaultTrapStyleName" GeometricBounds="0 0 {PAGE_H} {PAGE_W}" '
            f'ItemTransform="1 0 0 1 {DX} {DY}" AppliedMaster="n" OverrideList="" TabOrder="" GridStartingPoint="TopOutside" UseMasterGrid="true">'
            '<Properties><PageColor type="enumeration">UseMasterColor</PageColor></Properties>'
            '<MarginPreference ColumnCount="3" ColumnGutter="0" Top="18" Bottom="18" Left="18" Right="18" ColumnDirection="Horizontal" ColumnsPositions="0 396 396 792 792 1188"/>'
            '</Page>' + "".join(items) + '</Spread></idPkg:Spread>')

spreads = {"sp1": spread_xml("sp1", 1, page1), "sp2": spread_xml("sp2", 2, page2)}

def designmap():
    x = [HDR, '<?aid style="50" type="document" readerVersion="6.0" featureSet="257" product="15.0(20)" ?>',
         f'<Document {NS} DOMVersion="{DOM}" Self="d" StoryList="{" ".join(story_files)}" Name="{html.escape(IDML_NAME)}" ZeroPoint="0 0" '
         'ActiveLayer="ua" CMYKProfile="U.S. Web Coated (SWOP) v2" RGBProfile="sRGB IEC61966-2.1" SolidColorIntent="UseColorSettings" '
         'AfterBlendingIntent="UseColorSettings" DefaultImageIntent="UseColorSettings" RGBPolicy="PreserveEmbeddedProfiles" '
         'CMYKPolicy="CombinationOfPreserveEmbeddedProfilesAndPreserveNumbers" AccurateLABSpots="false">',
         '<Language Self="Language/$ID/English%3a USA" Name="$ID/English: USA" SingleQuotes="‘’" DoubleQuotes="“”" PrimaryLanguageName="$ID/English" SublanguageName="$ID/USA" Id="269" HyphenationVendor="Hunspell" SpellingVendor="Hunspell"/>',
         '<idPkg:Graphic src="Resources/Graphic.xml"/>', '<idPkg:Fonts src="Resources/Fonts.xml"/>',
         '<idPkg:Styles src="Resources/Styles.xml"/>', '<idPkg:Preferences src="Resources/Preferences.xml"/>',
         '<idPkg:Tags src="XML/Tags.xml"/>',
         '<Layer Self="ua" Name="Layer 1" Visible="true" Locked="false" IgnoreWrap="false" ShowGuides="true" LockGuides="false" UI="true" Expendable="true" Printable="true"><Properties><LayerColor type="enumeration">LightBlue</LayerColor></Properties></Layer>']
    for s in spreads: x.append(f'<idPkg:Spread src="Spreads/Spread_{s}.xml"/>')
    x.append('<idPkg:BackingStory src="XML/BackingStory.xml"/>')
    for s in story_files: x.append(f'<idPkg:Story src="Stories/Story_{s}.xml"/>')
    x.append('</Document>')
    return "".join(x)

def backing_story():
    return (HDR + f'<idPkg:BackingStory {NS} DOMVersion="{DOM}">'
            '<XmlStory Self="uXmlStory" AppliedTOCStyle="n" TrackChanges="false" StoryTitle="$ID/" AppliedNamedGrid="n">'
            '<StoryPreference OpticalMarginAlignment="false" OpticalMarginSize="12" FrameType="TextFrameType" StoryOrientation="Horizontal" StoryDirection="LeftToRightDirection"/>'
            '<InCopyExportOption IncludeGraphicProxies="true" IncludeAllResources="false"/>'
            '<XMLElement Self="di2" MarkupTag="XMLTag/Root" XMLContent="d"/>'
            '</XmlStory></idPkg:BackingStory>')

def tags_xml():
    return (HDR + f'<idPkg:Tags {NS} DOMVersion="{DOM}"><XMLTag Self="XMLTag/Root" Name="Root">'
            '<Properties><TagColor type="enumeration">LightBlue</TagColor></Properties></XMLTag></idPkg:Tags>')

# ------------------------------------------------------------------ write package
os.makedirs(OUT_DIR, exist_ok=True)
path = os.path.join(OUT_DIR, IDML_NAME)
with zipfile.ZipFile(path, "w") as z:
    z.writestr(zipfile.ZipInfo("mimetype"), "application/vnd.adobe.indesign-idml-package", compress_type=zipfile.ZIP_STORED)
    def add(name, data): z.writestr(name, data, compress_type=zipfile.ZIP_DEFLATED)
    add("META-INF/container.xml", HDR + '<container xmlns="urn:oasis:names:tc:opendocument:xmlns:container" version="1.0">'
        '<rootfiles><rootfile full-path="designmap.xml" media-type="text/xml"/></rootfiles></container>')
    add("designmap.xml", designmap())
    add("Resources/Graphic.xml", graphic_xml())
    add("Resources/Fonts.xml", fonts_xml())
    add("Resources/Styles.xml", styles_xml())
    add("Resources/Preferences.xml", prefs_xml())
    add("XML/Tags.xml", tags_xml())
    add("XML/BackingStory.xml", backing_story())
    for s, xml in spreads.items(): add(f"Spreads/Spread_{s}.xml", xml)
    for s, xml in story_files.items(): add(f"Stories/Story_{s}.xml", xml)
print("wrote", path, "stories", len(story_files))
